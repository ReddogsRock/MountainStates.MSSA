# SASS / SCSS Files to Generate CSS

These files generate the final CSS both for bootstrap 3 and 4,
and could be enhanced to easily support more CSS frameworks.

If you want to customize the CSS, you will usually only need one of these,
so just open the relevant bs3.scss or bs4.scss and read the instructions.