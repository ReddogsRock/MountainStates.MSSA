namespace AppCode
{
  public static class Constants
  {
    public const string ClassMobiusField = "app-mobius6-form-fields";

    public const string ClassCheckbox = "form-check-input";

    public const string ClassRequired = "app-mobius6-field-required";
  }
}