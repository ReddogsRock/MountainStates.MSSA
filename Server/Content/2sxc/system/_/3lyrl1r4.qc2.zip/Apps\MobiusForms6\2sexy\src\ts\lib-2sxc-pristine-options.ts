// This is only partial - if you want to see more, see https://fancyapps.com/docs/ui/fancybox/options
export interface PristineOptions {
  classTo: string;
  errorClass?: string;
  successClass?: string;
  errorTextParent: string;
  errorTextTag?: string;
  errorTextClass?: string;
}